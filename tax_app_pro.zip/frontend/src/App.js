import React,{useState} from 'react';import axios from 'axios';
export default function App(){
const [income,setIncome]=useState('');
const calc=async()=>{
const r=await axios.post('http://localhost:5000/api/tax/paye',{income});
alert(r.data.tax)};
return(<div><h1>Tax</h1><input onChange={e=>setIncome(e.target.value)}/><button onClick={calc}>Calc</button></div>)}
